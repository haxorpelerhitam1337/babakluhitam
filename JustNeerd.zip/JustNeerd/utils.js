// core/utils.js
const sleep = (s) => new Promise(r => setTimeout(r, s * 1000));

async function mouser(page) {
  const box = { x: 200, y: 300 };
  await page.mouse.move(box.x, box.y);
  await page.mouse.down();
  await sleep(0.2);
  await page.mouse.move(box.x + 150, box.y + 10, { steps: 25 });
  await page.mouse.up();
  await sleep(0.3);
}

module.exports = { sleep, mouser };
