const fs = require('fs');
const axios = require('axios');
const utils = require('../lib/utils');

/**
 * Scrapes proxies from xcddos.xyz Indonesian proxy sources
 * @param {Function} reportProgress - Function to report progress
 * @returns {Promise<{total: number, valid: number, indo: number}>}
 */
async function xcddos(reportProgress = () => {}) {
  const sources = [
    'https://sharedidexp13mei2025.xcddos.xyz/',
    'https://shared-proxy-id.xcddos.xyz/'
  ];
  let total = 0;
  let valid = 0;
  let indo = 0;
  let allProxies = [];
  try {
    for (const url of sources) {
      try {
        const response = await axios.get(url, {
          timeout: 30000,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9'
          }
        });
        const ipPortRegex = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}/g;
        const matches = response.data.match(ipPortRegex);
        
        if (matches && matches.length > 0) {
          allProxies = [...allProxies, ...matches];
        }
      } catch (error) {
      }
    }
    if (allProxies.length > 0) {
      total = allProxies.length;
      for (let i = 0; i < allProxies.length; i++) {
        const proxy = allProxies[i];
        reportProgress(i + 1);        
        try {
          await utils.writeProxy(proxy, true);
          valid++;
          indo++;
        } catch (error) {
        }
      }
    }
  } catch (error) {
  }
  
  return { total, valid, indo };
}

module.exports = xcddos;