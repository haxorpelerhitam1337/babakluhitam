const axios = require("axios");
const cheerio = require("cheerio");
const utils = require("../lib/utils");

const fetchProxyScrape = async () => {
  try {
    console.log(`Fetching from ProxyScrape API`);
    const startTime = Date.now();
    const urls = [
      "https://proxyscrape.com/free-proxy-list/http",
      "https://proxyscrape.com/free-proxy-list/socks4",
      "https://proxyscrape.com/free-proxy-list/socks5",
    ];
    
    let totalProxyCount = 0;
    let totalValidCount = 0;
    let totalIndoCount = 0;
    const axiosInstance = utils.createAxiosInstance(axios);

    for (const url of urls) {
      try {
        console.log(`Fetching from ${url}`);
        const response = await axiosInstance.get(url);
        if (response.status === 200) {
          const $ = cheerio.load(response.data);
          let proxyList = [];
          const proxyRows = $("table.table tbody tr");
          
          if (proxyRows.length > 0) {
            proxyRows.each((i, row) => {
              const columns = $(row).find("td");
              if (columns.length >= 2) {
                const ip = $(columns[0]).text().trim();
                const port = $(columns[1]).text().trim();
                if (ip && port) {
                  const proxyString = `${ip}:${port}`;
                  proxyList.push(proxyString);
                }
              }
            });
          } else {
            const pageText = response.data;
            const ipPortRegex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}\b/g;
            const matches = pageText.match(ipPortRegex);
            if (matches && matches.length > 0) {
              proxyList = matches;
            }
          }
          
          totalProxyCount += proxyList.length;
          if (proxyList.length > 0) {
            const results = await utils.processProxies(proxyList);
            totalValidCount += results.valid;
            totalIndoCount += results.indo;

            console.log(
              `ProxyScrape ${url.includes("http") ? "HTTP" : url.includes("socks4") ? "SOCKS4" : "SOCKS5"}: Found ${proxyList.length} proxies`,
            );
          } else {
            console.log(`No proxies found on ${url}`);
          }
        }
      } catch (error) {
        console.error(`Error fetching from ${url}:`, error.message);
      }
    }
    
    try {
      const directUrls = [
        "https://api.proxyscrape.com/?request=displayproxies&proxytype=http",
        "https://api.proxyscrape.com/?request=displayproxies&proxytype=socks4",
        "https://api.proxyscrape.com/?request=displayproxies&proxytype=socks5",
      ];

      for (const url of directUrls) {
        try {
          console.log(`Trying alternative URL: ${url}`);
          const response = await axiosInstance.get(url, {
            timeout: 5000,
          });

          if (response.status === 200 && typeof response.data === "string") {
            const proxyList = response.data.split("\n").filter((line) => line.trim() !== "");
            totalProxyCount += proxyList.length;
            const results = await utils.processProxies(proxyList);
            totalValidCount += results.valid;
            totalIndoCount += results.indo;

            console.log(
              `ProxyScrape alternative ${url.includes("http") ? "HTTP" : url.includes("socks4") ? "SOCKS4" : "SOCKS5"}: Found ${proxyList.length} proxies`,
            );
          }
        } catch (error) {
          console.error(`Error fetching from alternative URL ${url}:`, error.message);
        }
      }
    } catch (error) {
      console.error(`Error trying alternative ProxyScrape URLs:`, error.message);
    }

    const timeElapsed = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(
      `✅ ProxyScrape: Found ${totalProxyCount} proxies (${totalValidCount} valid, ${totalIndoCount} Indonesian) in ${timeElapsed}s`,
    );
    
    return { total: totalProxyCount, valid: totalValidCount, indo: totalIndoCount };
  } catch (error) {
    console.error(`❌ Error fetching proxies from ProxyScrape:`, error.message);
    return { total: 0, valid: 0, indo: 0 };
  }
};

module.exports = fetchProxyScrape;